package model;

public class Course {
	private int majorId,planId,courseId,semester;
	private String planName,courseName;
	public Course(int majorId, int planId, int courseId, int semester, String planName, String courseName) {
		super();
		this.majorId = majorId;
		this.planId = planId;
		this.courseId = courseId;
		this.semester = semester;
		this.planName = planName;
		this.courseName = courseName;
	}
	public Course(int planId, int semester, String courseName) {
		super();
		this.planId = planId;
		this.semester = semester;
		this.courseName = courseName;
	}
	public Course(int planId, int courseId, int semester, String courseName) {
		super();
		this.planId = planId;
		this.courseId = courseId;
		this.semester = semester; 
		this.courseName = courseName;
	}
	public int getMajorId() {
		return majorId;
	}
	public void setMajorId(int majorId) {
		this.majorId = majorId;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	@Override
	public String toString() {
		return courseName;
	}

}
