package model;
//�꼶ѡ��ģ����
public class GradeCourse {
	private int id,majorId,grade,planId;

	public GradeCourse(int id, int majorId, int grade, int planId) {
		super();
		this.id = id;
		this.majorId = majorId;
		this.grade = grade;
		this.planId = planId;
	}

	public GradeCourse(int majorId, int grade, int planId) {
		super();
		this.majorId = majorId;
		this.grade = grade;
		this.planId = planId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMajorId() {
		return majorId;
	}

	public void setMajorId(int majorId) {
		this.majorId = majorId;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	@Override
	public String toString() {
		return grade+"��";
	}
	
}
