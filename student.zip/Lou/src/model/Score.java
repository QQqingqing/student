package model;

public class Score {
	private int courseId,planId,semester,studentId,classId,studentNumber,scoreId,score;
	private char studentSex;
	private String courseName,studentName;
	public Score(int courseId, int planId, int semester, int studentId, int classId, int studentNumber, int scoreId,
			int score, char studentSex, String courseName, String studentName) {
		super();
		this.courseId = courseId;
		this.planId = planId;
		this.semester = semester;
		this.studentId = studentId;
		this.classId = classId;
		this.studentNumber = studentNumber;
		this.scoreId = scoreId;
		this.score = score;
		this.studentSex = studentSex;
		this.courseName = courseName;
		this.studentName = studentName;
	}
	public Score(int courseId, int studentId) {
		super();
		this.courseId = courseId;
		this.studentId = studentId;
	}
	public Score(int courseId, int studentId, int scoreId, int score) {
		super();
		this.courseId = courseId;
		this.studentId = studentId;
		this.scoreId = scoreId;
		this.score = score;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(int studentNumber) {
		this.studentNumber = studentNumber;
	}
	public int getScoreId() {
		return scoreId;
	}
	public void setScoreId(int scoreId) {
		this.scoreId = scoreId;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public char getStudentSex() {
		return studentSex;
	}
	public void setStudentSex(char studentSex) {
		this.studentSex = studentSex;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

}
