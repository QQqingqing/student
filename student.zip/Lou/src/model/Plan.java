package model;
//��ѧ�ƻ�ģ����
public class Plan {
	private int planId,majorId,collegeId;
	private String majorName,planName;
	public Plan(int planId, int majorId, int collegeId, String majorName, String planName) {
		super();
		this.planId = planId;
		this.majorId = majorId;
		this.collegeId = collegeId;
		this.majorName = majorName;
		this.planName = planName;
	}
	public Plan(int majorId, String planName) {
		super();
		this.majorId = majorId;
		this.planName = planName;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public int getMajorId() {
		return majorId;
	}
	public void setMajorId(int majorId) {
		this.majorId = majorId;
	}
	public int getCollegeId() {
		return collegeId;
	}
	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}
	public String getMajorName() {
		return majorName;
	}
	public void setMajorName(String majorName) {
		this.majorName = majorName;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	@Override
	public String toString() {
		return planName;
	}

}
