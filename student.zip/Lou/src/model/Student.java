package model;
//ѧ��ģ����
public class Student {
	private int majorId,classId,grade,studentId,studentNumber;
	private String className,studentName;
	private char studentSex;
	public Student(int majorId, int classId, int grade, int studentId, int studentNumber, String className,
			String studentName, char studentSex) {
		super();
		this.majorId = majorId;
		this.classId = classId;
		this.grade = grade;
		this.studentId = studentId;
		this.studentNumber = studentNumber;
		this.className = className;
		this.studentName = studentName;
		this.studentSex = studentSex;
	}
	public Student(int classId, int studentNumber, String studentName, char studentSex) {
		super();
		this.classId = classId;
		this.studentNumber = studentNumber;
		this.studentName = studentName;
		this.studentSex = studentSex;
	}
	public Student(int classId, int studentId, int studentNumber, String className, char studentSex) {
		super();
		this.classId = classId;
		this.studentId = studentId;
		this.studentNumber = studentNumber;
		this.className = className;
		this.studentSex = studentSex;
	}
	public int getMajorId() {
		return majorId;
	}
	public void setMajorId(int majorId) {
		this.majorId = majorId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(int studentNumber) {
		this.studentNumber = studentNumber;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public char getStudentSex() {
		return studentSex;
	}
	public void setStudentSex(char studentSex) {
		this.studentSex = studentSex;
	}
	@Override
	public String toString() {
		return className+","+studentNumber+","+studentName;
	}
	
}
