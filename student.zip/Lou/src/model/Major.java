package model;
//רҵģ����
public class Major {
	private int majorId,collegeId,lengthOfSchoolng;
	private String majorName,collegeName;
	public Major(int majorId, int collegeId, int lengthOfSchoolng, String majorName, String collegeName) {
		super();
		this.majorId = majorId;
		this.collegeId = collegeId;
		this.lengthOfSchoolng = lengthOfSchoolng;
		this.majorName = majorName;
		this.collegeName = collegeName;
	}
	public Major(int collegeId, int lengthOfSchoolng, String majorName) {
		super();
		this.collegeId = collegeId;
		this.lengthOfSchoolng = lengthOfSchoolng;
		this.majorName = majorName;
	}
	public int getMajorId() {
		return majorId;
	}
	public void setMajorId(int majorId) {
		this.majorId = majorId;
	}
	public int getCollegeId() {
		return collegeId;
	}
	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}
	public int getLengthOfSchoolng() {
		return lengthOfSchoolng;
	}
	public void setLengthOfSchoolng(int lengthOfSchoolng) {
		this.lengthOfSchoolng = lengthOfSchoolng;
	}
	public String getMajorNameString() {
		return majorName;
	}
	public void setMajorNameString(String majorName) {
		this.majorName = majorName;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	@Override
	public String toString() {
		return majorName;
	}
	
}
