package model;

public class ClassInfo {
	private int collegeId, majorId, lengthOfSchoolng, grade, classId;
	private String majorName, className;
	public ClassInfo(int collegeId, int majorId, int lengthOfSchoolng, int grade, int classId, String majorName,
			String className) {
		super();
		this.collegeId = collegeId;
		this.majorId = majorId;
		this.lengthOfSchoolng = lengthOfSchoolng;
		this.grade = grade;
		this.classId = classId;
		this.majorName = majorName;
		this.className = className;
	}
	public ClassInfo(int majorId, int grade, String className) {
		super();
		this.majorId = majorId;
		this.grade = grade;
		this.className = className;
	}
	public ClassInfo(int majorId, int grade, int classId, String className) {
		super();
		this.majorId = majorId;
		this.grade = grade;
		this.classId = classId;
		this.className = className;
	}
	public int getCollegeId() {
		return collegeId;
	}
	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}
	public int getMajorId() {
		return majorId;
	}
	public void setMajorId(int majorId) {
		this.majorId = majorId;
	}
	public int getLengthOfSchoolng() {
		return lengthOfSchoolng;
	}
	public void setLengthOfSchoolng(int lengthOfSchoolng) {
		this.lengthOfSchoolng = lengthOfSchoolng;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getMajorName() {
		return majorName;
	}
	public void setMajorName(String majorName) {
		this.majorName = majorName;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	@Override
	public String toString() {
		return className;
	}
	
}
