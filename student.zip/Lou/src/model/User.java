package model;

public class User {
	private String usernam,password;

	public String getUsernam() {
		return usernam;
	}

	public void setUsernam(String usernam) {
		this.usernam = usernam;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public User(String usernam, String password) {
		super();
		this.usernam = usernam;
		this.password = password;
	}
}
