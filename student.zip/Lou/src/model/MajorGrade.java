package model;
//רҵ�꼶ģ����
public class MajorGrade {
	public int majorId,grade;

	public MajorGrade(int majorId, int grade) {
		super();
		this.majorId = majorId;
		this.grade = grade;
	}

	public int getMajorId() {
		return majorId;
	}

	public void setMajorId(int majorId) {
		this.majorId = majorId;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return grade+"��";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + grade;
		result = prime * result + majorId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MajorGrade other = (MajorGrade) obj;
		if (grade != other.grade)
			return false;
		if (majorId != other.majorId)
			return false;
		return true;
	}
	
	
}
